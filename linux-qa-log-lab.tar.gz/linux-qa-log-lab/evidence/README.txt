Папка для доказательств.
Сохраняйте сюда результаты поиска, например:
    grep "req-XXXXXXXX" logs/app.log > evidence/QA-XXX-req-XXXXXXXX.txt
(вместо req-XXXXXXXX подставьте request ID, который нашли сами)
