#!/usr/bin/env bash
# Отчёт о среде: кто я, какая система, как работают права.
# Запуск из папки linux-qa-log-lab:  bash tools/env-report.sh
echo "== Пользователь";  whoami; id
echo "== Домашняя папка: $HOME"
echo "== Система";       grep PRETTY_NAME /etc/os-release
echo "== Версии";        grep --version | head -n 1; ls --version | head -n 1; bash --version | head -n 1
echo "== Дата и часовой пояс"; date
echo "== sudo"
if command -v sudo >/dev/null 2>&1; then
  echo "sudo есть: $(command -v sudo)"
  if sudo -n true 2>/dev/null; then echo "sudo без пароля: да"; else echo "sudo без пароля: нет"; fi
else
  echo "sudo: НЕТ"
fi
echo "== Права"
t="$HOME/.env-report-test.sh"
echo 'echo ok' > "$t"; chmod 644 "$t"
if "$t" >/dev/null 2>&1; then echo "запуск файла без права x: РАЗРЕШЁН"; else echo "запуск файла без права x: Permission denied"; fi
chmod 000 "$t"
if cat "$t" >/dev/null 2>&1; then echo "чтение файла с правами 000: РАЗРЕШЕНО"; else echo "чтение файла с правами 000: Permission denied"; fi
rm -f "$t"
echo "== Программы"
for c in less top ps find grep tail head wc sha256sum; do printf '%-10s ' "$c"; command -v "$c" || echo "НЕТ"; done
