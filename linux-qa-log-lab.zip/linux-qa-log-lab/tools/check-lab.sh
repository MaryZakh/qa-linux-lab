#!/usr/bin/env bash
# Проверка учебного стенда linux-qa-log-lab.
# Запуск из папки linux-qa-log-lab:  bash tools/check-lab.sh
cd "$(dirname "$0")/.." || { echo "Не найдена папка стенда"; exit 1; }
ok=1
echo "== 1. Файлы на месте и не изменены =="
if command -v sha256sum >/dev/null 2>&1; then SHA="sha256sum"; else SHA="shasum -a 256"; fi
$SHA -c tools/checksums.sha256 || ok=0
echo
echo "== 2. Контрольные числа =="
expect() {  # описание, ожидаемое, фактическое
  if [ "$2" = "$3" ]; then echo "OK    $1: $3"; else echo "ОШИБКА $1: ожидалось $2, получено $3"; ok=0; fi
}
expect "строк в logs/app.log"                68 "$(wc -l < logs/app.log | tr -d ' ')"
expect "строк в logs/access.log"             27 "$(wc -l < logs/access.log | tr -d ' ')"
expect "строк ERROR в logs/app.log"          6 "$(grep -c "ERROR" logs/app.log)"
expect "ответов 500 в logs/access.log"       2 "$(grep -c '" 500 ' logs/access.log)"
expect "строк с req-8c41f2e7 во всех логах"  10 "$(grep -r "req-8c41f2e7" logs | wc -l | tr -d ' ')"
echo
if [ $ok -eq 1 ]; then echo "ИТОГ: стенд в порядке."; else echo "ИТОГ: стенд повреждён — заново выполните 3 команды загрузки стенда."; fi
