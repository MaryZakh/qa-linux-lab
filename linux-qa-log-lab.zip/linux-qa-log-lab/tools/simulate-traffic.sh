#!/usr/bin/env bash
# Учебный генератор "живого" трафика: дописывает строки в logs/live.log.
# Запуск из папки linux-qa-log-lab:  bash tools/simulate-traffic.sh
# Работает около 30 секунд, затем завершается сам.
cd "$(dirname "$0")/.." || exit 1
LOG=logs/live.log
lines=(
"INFO  [req-e1000001] BookingController - GET /api/v1/bookings received (userId=user_001)"
"INFO  [req-e1000001] BookingController - Responded 200 OK in 31ms"
"INFO  [req-e1000002] BookingController - POST /api/v1/bookings received (userId=user_009)"
"WARN  [req-e1000002] BookingValidator - validation error: guest age 17 is below minimum 18"
"INFO  [req-e1000002] BookingController - Responded 400 Bad Request in 9ms"
"INFO  [req-e1000003] BookingController - POST /api/v1/bookings received (userId=user_007)"
"WARN  [req-e1000003] PromoService - Promo code WINTER26 not found or expired, returning empty discount"
"ERROR [req-e1000003] PriceCalculator - Failed to calculate total price: discount is null (see error.log)"
"ERROR [req-e1000003] BookingService - Booking creation failed, transaction rolled back"
"INFO  [req-e1000003] BookingController - Responded 500 Internal Server Error in 49ms"
"INFO  [req-e1000004] BookingController - GET /api/v1/bookings/BK-2026-0014 received (userId=user_007)"
"INFO  [req-e1000004] BookingController - Responded 200 OK in 20ms"
)
touch "$LOG"
echo "simulate-traffic: пишу ${#lines[@]} строк в $LOG (по одной в 2-3 секунды)..."
for l in "${lines[@]}"; do
  echo "$(date '+%Y-%m-%d %H:%M:%S.000') $l" >> "$LOG"
  sleep 2.5
done
echo "simulate-traffic: готово."
