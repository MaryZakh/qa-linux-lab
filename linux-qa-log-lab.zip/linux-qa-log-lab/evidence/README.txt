Папка для доказательств.
Сохраняйте сюда результаты поиска, например:
    grep "req-8c41f2e7" logs/app.log > evidence/req-8c41f2e7-app.txt
